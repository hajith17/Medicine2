package com.project.service;

import com.project.model.SignupModel;

public interface SignupService{

	public abstract SignupModel createAccount(SignupModel signupModel);
	
}