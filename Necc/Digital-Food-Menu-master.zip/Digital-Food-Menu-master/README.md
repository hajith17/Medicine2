> A Digital Restaurant-Menu web-application, containing all 4 CRUD operations
